document.querySelectorAll('.dropdown-toggle').forEach(function (toggle) {
    toggle.addEventListener('click', function (event) {
      event.preventDefault();
      
      // Menampilkan atau menyembunyikan konten dropdown
      const listItem = this.parentElement;
      listItem.classList.toggle('open');
      
      // Menambahkan efek rotate pada ikon
      const icon = this.querySelector('.fa');
      icon.classList.toggle('rotate');
    });
  });